from random import randint
import urllib
import urllib2
import time
import datetime
import serial

url = 'http://wepark.online/api/Publishapi'
counter = 0

com_port = raw_input("Enter COM port:")
print(com_port)
if com_port is not None:
    ser = serial.Serial(com_port, 9600)


while True:
	data = ser.readline()
	data = data.replace('Received: ','')
	state = 0
	#check if there is a car under/above the sensor
	try:
		if int(data) < 50:
			state = 1
		else:
			state = 0
	except ValueError:
		print 'omg!'
	print(data)
	#delay
	#print counter
	counter += 1
	#time.sleep(10)
	#get random values
	id = randint(0,100)
	spaceId = randint(0,100)
	#get timestamp
	ts = time.time()
	st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
	
	#compile the struct
	params = urllib.urlencode({
  		"Id": id,
  		"SpaceId": spaceId,
  		"CurrentState": state ,
  		"TransStamp": st
	})

	#simply try to send it
	try:
		response = urllib2.urlopen(url, params).read()
		print response
	except:
		print "oops!"
